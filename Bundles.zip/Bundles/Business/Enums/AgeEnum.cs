﻿namespace Business
{
    public enum AgeEnum
    {
        Undefined = 0,

        FromZeroToSeventeen = 1,

        FromEighteenToSixtyFour = 2,

        SixtyFivePlus = 3
    }
}
