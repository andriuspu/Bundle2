﻿namespace Business
{
    public enum IncomeEnum
    {
        Undefined = 0,

        Zero = 1,

        FromOneToTwelveThousand = 2,

        FromTwelveThousandOneToFortyThousand = 3,

        FortyThousandOnePlus = 4
    }
}
