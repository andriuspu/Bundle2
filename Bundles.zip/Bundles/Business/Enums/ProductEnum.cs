﻿namespace Business
{
    public enum ProductEnum
    {
        Undefined = 0,

        CurrentAccount = 1,

        CurrentAccountPlus = 2,

        JuniorSaverAccount = 3,

        StudentAccount = 4,

        DebitCard = 5,

        CreditCard = 6,

        GoldCreditCard = 7
    }
}
