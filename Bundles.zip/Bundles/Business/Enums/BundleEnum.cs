﻿namespace Business
{
    public enum BundleEnum
    {
        Undefined = 0,

        JuniorSaver = 1,

        Student = 2,

        Classic = 3,

        ClassicPlus = 4,

        Gold = 5
    }
}
