﻿using System.Collections.Generic;

namespace Data
{
    public class JuniorSaverBundle : Bundle
    {
        public JuniorSaverBundle(string name, List<Product> productList, int value) : base(name, productList, value)
        {
        }
    }
}
