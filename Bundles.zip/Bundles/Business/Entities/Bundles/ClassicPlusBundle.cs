﻿using System.Collections.Generic;

namespace Data
{
    public class ClassicPlusBundle : Bundle
    {
        public ClassicPlusBundle(string name, List<Product> productList, int value) : base(name, productList, value)
        {
        }
    }
}
