﻿using System.Collections.Generic;

namespace Data
{
    public class ClassicBundle : Bundle
    {
        public ClassicBundle(string name, List<Product> productList, int value) : base(name, productList, value)
        {
        }
    }
}
