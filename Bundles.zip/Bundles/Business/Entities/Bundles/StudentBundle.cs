﻿using System.Collections.Generic;

namespace Data
{
    public class StudentBundle : Bundle
    {
        public StudentBundle(string name, List<Product> productList, int value) : base(name, productList, value)
        {
        }
    }
}
