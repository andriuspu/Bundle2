﻿using System.Collections.Generic;

namespace Data
{
    public class GoldBundle : Bundle
    {
        public GoldBundle(string name, List<Product> productList, int value) : base(name, productList, value)
        {
        }
    }
}
