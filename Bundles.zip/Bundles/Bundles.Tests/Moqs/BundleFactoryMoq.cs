﻿using Data;

namespace Business
{
    public class BundleFactoryMoq : IBundleFactory
    {
        public Bundle Create(int bundleId)
        {
            return null;
        }
    }
}
