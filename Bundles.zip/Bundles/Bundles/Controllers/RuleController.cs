﻿using System.Web.Mvc;

namespace Bundles.Controllers
{
    public class RuleController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
