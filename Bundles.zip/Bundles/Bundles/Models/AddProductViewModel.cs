﻿using Data;

namespace Bundles.Models
{
    public class AddProductViewModel
    {
        public int CustomerId { get; set; }
        public int ProductId { get; set; }        
    }
}