﻿using Data;

namespace Bundles.Models
{
    public class MatchViewModel
    {
        public Customer Customer { get; set; }
        public int BundleId { get; set; }        
    }
}