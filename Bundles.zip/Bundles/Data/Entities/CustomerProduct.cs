﻿namespace Data
{
    public class CustomerProduct
    {
        public int CustomerId { get; set; }

        public int ProductId { get; set; }
    }
}
